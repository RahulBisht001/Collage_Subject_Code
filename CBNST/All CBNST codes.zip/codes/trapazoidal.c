/*
    trapazoidal
*/

#include <stdio.h>
#include <math.h>
int main()
{
    int n;
    printf("\t Trapozoidal Rule \n");
    printf("Enter the number of observation : ");
    scanf("%d",&n);
    double observation[n][2];
    printf("Enter the observations \n");
    for(int i=0;i<n;i++){
        scanf("%lf %lf",&observation[i][0],&observation[i][1]);
    }
    
    double h = observation[1][0] - observation[0][0], ans = 0;

    for(int i=1;i<n-1;i++)  ans += observation[i][1];
    ans *= 2;

    ans += observation[0][1] + observation[n-1][1];
    ans *= h;
    ans /= 2;

    printf("\nThe solution is %lf",ans);
    return 0;
}