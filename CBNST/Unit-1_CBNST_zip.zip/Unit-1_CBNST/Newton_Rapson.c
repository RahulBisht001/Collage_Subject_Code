/**
 * Newton Rapson Implementation
 */

#include <stdio.h>
#include <math.h>
#define EPSILON 0.00001

float f(float x)
{
    // return x * x - 12;
    // return x * x * x - 3 * x + 1;
    return (x * exp(x) - 1);
}

float differentiate(float x)
{
    // return 2 * x;
    // return 3 * x * x - 3;
    return (exp(x) + x * exp(x));
}

int main()
{
    float x1, x2, x, x0;
    int max_Iterations, i;

    printf("Enter max Iterations : ");
    scanf("%d", &max_Iterations);
    printf("\n");

    do
    {
        printf("Enter the value of x1 : ");
        scanf("%f", &x1);
        printf("\n");

        printf("Enter the value of x2 : ");
        scanf("%f", &x2);
        printf("\n");

        if (f(x1) * f(x2) > 0)
        {
            printf("Invalid Interval");
            printf("\n");
            continue;
        }
        else
        {
            printf("Roots Lie between %f and %f\n", x1, x2);
            printf("\n");
            break;
        }
    } while (1);

    if (fabs(x1) < fabs(x2))
    {
        x0 = x1;
    }
    else
    {
        x1 = x2;
    }

    for (i = 1; i <= max_Iterations; ++i)
    {
        x = x0 - (f(x0) / differentiate(x0));
        if (fabs(x - x0) < EPSILON)
        {
            printf("Iterations= %d  Final Root=%f\n", i, x);
            break;
        }
        printf("Iterations= %d  Root=%f\n", i, x);
        x0 = x;
    }

    printf("%f", x);
}

/**
// C Program to Implement Newton Rapson Method
#include <stdio.h>
#include <math.h>
#define EPSILON 0.00001

float f(float x)
{
    // return x * x - 12;
    return x * x * x - 3 * x + 1;
}

float differentiate(float x)
{
    // return 2 * x;
    return 3 * x * x - 3;
}

int main()
{
    int maxIteration, i;
    float x1, x2, x, x0;
    printf("Enter Maximum no of Iterations\n");
    scanf("%d", &maxIteration);

    //......Compute x1 and x2.............

    do
    {
        printf("Enter the value of x1 : ");
        scanf("%f", &x1);
        printf("\n");

        printf("Enter the value of x2 : ");
        scanf("%f", &x2);
        printf("\n");

        // printf("Enter the value of x1 and x2(starting boundary)");
        // scanf("%f%f", &x1, &x2);
        if (f(x1) * f(x2) > 0)
        {
            printf("Boundary Values are Invalid\n");
            continue;
        }
        else
        {
            printf("Roots Lie between %f and %f\n", x1, x2);
            break;
        }
    } while (1);

    // find x0
    if (fabs(f(x1)) < fabs(f(x2)))
        x0 = x1;
    else
        x1 = x2;

    // Apply Successive approximation to find the root b/w x1 and x2
    //..........Find root............
    for (i = 1; i <= maxIteration; i++)
    {
        x = x0 - (f(x0) / differentiate(x0));

        if (fabs(x - x0) < EPSILON)
        {
            printf("Iterations=%d  Final Root=%f\n", i, x);
            return 0;
        }
        printf("Iterations=%d  Roots=%f\n", i, x);
        x0 = x;
    }
    printf("Root=%f  Total Iterations=%d", x, --i);
    return 0;
}
*/

// ______ Rahul Sati _____
/**

#include <stdio.h>
#include <math.h>

float f(float x)
{
    return x * x * x - 2 * x - 5;
}

float differentiate(float x)
{
    return 3 * x * x - 2;
}

int main()
{
    int iterations, i = 1;
    float x, x0, x1, x2;
    printf("Enter the value of iterations : ");
    scanf("%d", &iterations);
    float ans = 0.0001;

    do
    {
        printf("Enter the value of x1 : ");
        scanf("%f", &x1);
        printf("\n");

        printf("Enter the value of x2 : ");
        scanf("%f", &x2);
        printf("\n");

        if (f(x1) * f(x2) > 0)
        {
            printf("Invalid roots\n");
        }
        else
            break;
    } while (1);

    x0 = (x1 + x2) / 2;

    for (int i = 1; i <= iterations; i++)
    {
        x = x0 - f(x0) / differentiate(x0);

        if (x - x0 < ans)
        {
            break;
        }

        x0 = x;
        printf("%d->%f", i, x);
    }

    printf("%f", x);
}
*/