printf("Solution of the given set of Equations:\n");
    for(int i=0;i<n;i++){
        printf("x%d=%.2lf\n",i+1,x[i]);
    }